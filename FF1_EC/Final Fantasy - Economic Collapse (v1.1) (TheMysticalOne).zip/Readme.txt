Final Fantasy - Economic Collapse
v1.1
by: The Mystical One

The destruction wrought by the fiends of chaos has caused the global economy to fall into ruin.
Shops shutter and fall into disrepair.
Magicians vanish to other realms, their students no longer able to afford their services...
Four heroes appear holding orbs, but they must find their own supplies and equipment.

- All shops have been closed and blocked off, their goods emptied.
- Inns and Clinics remain open
- Treasures and enemies are unchanged.
- Dungeon and overworld maps are unchanged.
- Includes Anomie's dash enhancement so you can run while suffering through the economic despair

Patches:
Final Fantasy (USA)
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)
SHA-1: 80CE108FBC066C985D4FB541BD68E9A7C8994FEB
CRC32: AB12ECE6